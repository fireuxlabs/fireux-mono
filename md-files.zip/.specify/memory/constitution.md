# FireUX Constitution

## Core Principles

### P1. Ship the canonical system

FireUX is pre-v1. Every change defines the canonical architecture; avoid speculative compatibility layers.

### P2. Fail fast, avoid silent fallbacks

Missing required inputs must surface clearly (error, blocking UI, or explicit placeholder); never hide issues with implicit defaults.

### P3. Minimize indirection

Prefer a single, explicit implementation over parallel helpers or shims; deduplicate aggressively.

## Constraints

### C1. No legacy layers, no hidden fallbacks (pre-v1)

- Do not create re-export shims or “bridge” files unless an existing caller cannot be updated in the same change.
- Do not add hidden fallbacks that auto-fill missing config/data; validate and fail loudly instead.
- Do not expose private fields as UI fallbacks (e.g., never use email when displayName is missing); use neutral placeholders or block the flow.
- If two functions/files do the same job, pick one, delete the other, and update call sites.
- After v1, migration layers may be added deliberately with docs; before v1, legacy does not exist.

## Workflow

- Copilot/agents must reference this constitution when proposing new helpers, fallbacks, or shims.
- Required fields (ecosystem, appId, displayName, etc.) must be validated; absence should stop the flow or show a neutral message.
- Prefer simplifying APIs over adding compatibility layers “just in case.”

## Governance

- This constitution supersedes other practices for FireUX pre-v1.
- Amendments require documenting intent, scope, and migration plan.

**Version**: 0.1.0 | **Ratified**: 2025-12-07 | **Last Amended**: 2025-12-07
