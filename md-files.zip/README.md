FireUX Monorepo

- Canonical docs: `packages/ecosystem/fireux-fireux/docs/`
- Agent/internal handbook: `copilot-documentation/`
- Prompts: `.github/prompts/`