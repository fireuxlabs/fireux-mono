---
title: Appendices (Placeholder)
status: draft
created: 2025-10-15
---

# Appendices

The appendices collect reference material that supports the main handbook chapters. Populate each topic as the new documentation set stabilises.

## Planned Sections

- Environment variable reference
- Command and script cheatsheet
- Troubleshooting playbooks
- Layout and navigation taxonomy
- Avatar/media system notes
- User update API reference

When authoring an appendix, create a new Markdown file in this directory and link to it from the list above. Use repository history to recover any pre-migration material you still need, then modernise it before copying over.
