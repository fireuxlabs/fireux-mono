# Documentation relocated

Docs now live at `packages/ecosystem/fireux-fireux/docs/`. Update bookmarks and links accordingly.
