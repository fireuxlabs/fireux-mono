# Documentation Markdown Collection

Grouped list of markdown files (node_modules and Nuxt caches excluded).

## Root & Ops
- ./AGENTS.md
- ./README.md
- ./automation/migrations/README.md
- ./documentation.md
- ./documentation-markdown-collection.md
- ./docs/README.md

## Prompts
- ./.github/prompts/speckit.analyze.prompt.md
- ./.github/prompts/speckit.checklist.prompt.md
- ./.github/prompts/speckit.clarify.prompt.md
- ./.github/prompts/speckit.constitution.prompt.md
- ./.github/prompts/speckit.implement.prompt.md
- ./.github/prompts/speckit.plan.prompt.md
- ./.github/prompts/speckit.specify.prompt.md
- ./.github/prompts/speckit.tasks.prompt.md

## Spec Kit
- ./.specify/memory/constitution.md
- ./.specify/templates/agent-file-template.md
- ./.specify/templates/checklist-template.md
- ./.specify/templates/plan-template.md
- ./.specify/templates/spec-template.md
- ./.specify/templates/tasks-template.md

## Copilot Docs (core)
- ./copilot-documentation/auth-ui.md
- ./copilot-documentation/copilot-00-toc.md
- ./copilot-documentation/copilot-01-orientation.md
- ./copilot-documentation/copilot-02-architecture.md
- ./copilot-documentation/copilot-03-configuration.md
- ./copilot-documentation/copilot-04-platform-services.md
- ./copilot-documentation/copilot-05-development-workflow.md
- ./copilot-documentation/copilot-06-ci-cd.md
- ./copilot-documentation/copilot-07-ux-conventions.md
- ./copilot-documentation/copilot-08-operations.md
- ./copilot-documentation/gap.md
- ./copilot-documentation/liturature.md
- ./copilot-documentation/model-interface.md
- ./copilot-documentation/package-docs-index.md
- ./copilot-documentation/roadmap.md

## Copilot ADRs
- ./copilot-documentation/copilot-adr/README.md
- ./copilot-documentation/copilot-adr/copilot-0001-nuxt-config-simplification.md
- ./copilot-documentation/copilot-adr/copilot-0002-src-first-no-dist.md
- ./copilot-documentation/copilot-adr/copilot-0003-vuefire-auth-init.md

## Copilot Appendices
- ./copilot-documentation/copilot-appendices/README.md
- ./copilot-documentation/copilot-appendices/profiles-model-summary.md
- ./copilot-documentation/copilot-appendices/theming-fireux-apps.md

## Copilot Instructions
- ./copilot-documentation/copilot-instructions/README.md
- ./copilot-documentation/copilot-instructions/backfill-app-memberships.md
- ./copilot-documentation/copilot-instructions/documentation-style.md

## Copilot Imported
- ./copilot-documentation/imported/packages/extensions/fireux-jobs/ROADMAP.md
- ./copilot-documentation/imported/root/config-report.md
- ./copilot-documentation/imported/root/create-and-register.md
- ./copilot-documentation/imported/root/deployment-config.md
- ./copilot-documentation/imported/root/ecosystem-change.md
- ./copilot-documentation/imported/root/profiles-stack.md
- ./copilot-documentation/imported/root/proposed-editable.dashboard-pages.md
- ./copilot-documentation/imported/root/server.md
- ./copilot-documentation/imported/root/stack-proposal.md
- ./copilot-documentation/imported/root/user-tree.md

## Canonical Docs (FireUX)
- ./packages/ecosystem/fireux-fireux/docs/00-overview/repo-structure.md
- ./packages/ecosystem/fireux-fireux/docs/10-core/figma.md
- ./packages/ecosystem/fireux-fireux/docs/10-core/images.md
- ./packages/ecosystem/fireux-fireux/docs/30-ecosystems/_index.md
- ./packages/ecosystem/fireux-fireux/docs/howto/work-on-app.md
- ./packages/ecosystem/fireux-fireux/docs/_manifest.md
- ./packages/ecosystem/fireux-fireux/docs/index.md
- ./packages/ecosystem/fireux-fireux/docs/gap.md
- ./packages/ecosystem/fireux-fireux/docs/liturature.md
- ./packages/ecosystem/fireux-fireux/docs/mission.md
- ./packages/ecosystem/fireux-fireux/docs/roadmap.md

## Packages: Core
- ./packages/core/fireux-core/dist/runtime/composables/fireux/firestore/core/user/STABLE_README.md
- ./packages/core/fireux-core/docs/figma.md
- ./packages/core/fireux-core/docs/gap.md
- ./packages/core/fireux-core/docs/images-sync.md
- ./packages/core/fireux-core/docs/images.md
- ./packages/core/fireux-core/docs/liturature.md
- ./packages/core/fireux-core/docs/mission.md
- ./packages/core/fireux-core/docs/molecules-forms.md
- ./packages/core/fireux-core/docs/roadmap.md
- ./packages/core/fireux-core/src/config/README.md
- ./packages/core/fireux-core/src/runtime/composables/fireux/firestore/core/user/STABLE_README.md

## Packages: Ecosystem (Cleanbox)
- ./packages/ecosystem/fireux-cleanbox/docs/gap.md
- ./packages/ecosystem/fireux-cleanbox/docs/liturature.md
- ./packages/ecosystem/fireux-cleanbox/docs/mission.md
- ./packages/ecosystem/fireux-cleanbox/docs/roadmap.md

## Packages: Ecosystem (FireUX)
- ./packages/ecosystem/fireux-fireux/README.md

### FireUX Archive: Scratch
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/scratch/alignment.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/scratch/blog.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/scratch/config.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/scratch/img.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/scratch/stacks-components.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/scratch/stacks-composables.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/scratch/stacks.md

### FireUX Archive: Temporary Reports
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/README.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/app-config.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/app-factory-report.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/app-report.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/app-utils.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/bloat-reduction-program.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/blog-report.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/chef-composables.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/composables/state-and-utils-report.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/composables/use.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/core-composables.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/current-pages-code.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/current-pages-components.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/current-pages-inventory.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/dashboard-dev-panels-todo.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/dev-health-roadmap.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/edit.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/ensure-report.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/firebse-operations-before.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/firestore-core-contract-2025-11.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/images-sync-temp.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/index-page.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/liturature-plan.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/navigation/legacy-nav-report.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/navigation/navigation-report.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/objects/legacy-firestore-objects-report.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/objects/product-composables-current.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/objects/product-composables-legacy.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/pill-report.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/scripts-audit.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/stack-scripts.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/stacks/app-v-user-comparison.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/stacks/use-app-stack.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/stacks/use-user-stack.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/tenants/landing.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/tenants/tenant-landing-follow-up.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/tree-report.md
- ./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/update-function.md

## Packages: Ecosystem (Misebox)
- ./packages/ecosystem/fireux-misebox/docs/gap.md
- ./packages/ecosystem/fireux-misebox/docs/liturature.md
- ./packages/ecosystem/fireux-misebox/docs/mission.md
- ./packages/ecosystem/fireux-misebox/docs/roadmap.md

## Packages: Ecosystem (Test)
- ./packages/ecosystem/fireux-test/README.md
- ./packages/ecosystem/fireux-test/docs/gap.md
- ./packages/ecosystem/fireux-test/docs/liturature.md
- ./packages/ecosystem/fireux-test/docs/mission.md
- ./packages/ecosystem/fireux-test/docs/roadmap.md

## Packages: Extensions
- ./packages/extensions/fireux-blogs/README.md
- ./packages/extensions/fireux-drop/README.md
- ./packages/extensions/fireux-ecosystem-controller/README.md
- ./packages/extensions/fireux-jobs/docs/gap.md
- ./packages/extensions/fireux-jobs/docs/liturature.md
- ./packages/extensions/fireux-jobs/docs/roadmap.md
- ./packages/extensions/fireux-places/docs/gap.md
- ./packages/extensions/fireux-places/docs/liturature.md
- ./packages/extensions/fireux-places/docs/places-overview.md
- ./packages/extensions/fireux-places/docs/roadmap.md
- ./packages/extensions/fireux-products/README.md

## Projects: Cleanbox
- ./projects/cleanbox/cleanbox-app/docs/gap.md
- ./projects/cleanbox/cleanbox-app/docs/liturature.md
- ./projects/cleanbox/cleanbox-app/docs/mission.md
- ./projects/cleanbox/cleanbox-app/docs/roadmap.md
- ./projects/cleanbox/richies-reinigung/docs/gap.md
- ./projects/cleanbox/richies-reinigung/docs/liturature.md
- ./projects/cleanbox/richies-reinigung/docs/mission.md
- ./projects/cleanbox/richies-reinigung/docs/roadmap.md

## Projects: FireUX
- ./projects/fireux/fireux-app/docs/gap.md
- ./projects/fireux/fireux-app/docs/liturature.md
- ./projects/fireux/fireux-app/docs/mission.md
- ./projects/fireux/fireux-app/docs/roadmap.md
- ./projects/fireux/tennant/docs/gap.md
- ./projects/fireux/tennant/docs/liturature.md
- ./projects/fireux/tennant/docs/mission.md
- ./projects/fireux/tennant/docs/roadmap.md

## Projects: Misebox
- ./projects/misebox/misebox-app/docs/gap.md
- ./projects/misebox/misebox-app/docs/liturature.md
- ./projects/misebox/misebox-app/docs/mission.md
- ./projects/misebox/misebox-app/docs/roadmap.md
- ./projects/misebox/niederhorn/docs/gap.md
- ./projects/misebox/niederhorn/docs/liturature.md
- ./projects/misebox/niederhorn/docs/mission.md
- ./projects/misebox/niederhorn/docs/roadmap.md./.github/prompts/speckit.analyze.prompt.md
./.github/prompts/speckit.checklist.prompt.md
./.github/prompts/speckit.clarify.prompt.md
./.github/prompts/speckit.constitution.prompt.md
./.github/prompts/speckit.implement.prompt.md
./.github/prompts/speckit.plan.prompt.md
./.github/prompts/speckit.specify.prompt.md
./.github/prompts/speckit.tasks.prompt.md
./.specify/memory/constitution.md
./.specify/templates/agent-file-template.md
./.specify/templates/checklist-template.md
./.specify/templates/plan-template.md
./.specify/templates/spec-template.md
./.specify/templates/tasks-template.md
./AGENTS.md
./README.md
./automation/migrations/README.md
./copilot-documentation/auth-ui.md
./copilot-documentation/copilot-00-toc.md
./copilot-documentation/copilot-01-orientation.md
./copilot-documentation/copilot-02-architecture.md
./copilot-documentation/copilot-03-configuration.md
./copilot-documentation/copilot-04-platform-services.md
./copilot-documentation/copilot-05-development-workflow.md
./copilot-documentation/copilot-06-ci-cd.md
./copilot-documentation/copilot-07-ux-conventions.md
./copilot-documentation/copilot-08-operations.md
./copilot-documentation/copilot-adr/README.md
./copilot-documentation/copilot-adr/copilot-0001-nuxt-config-simplification.md
./copilot-documentation/copilot-adr/copilot-0002-src-first-no-dist.md
./copilot-documentation/copilot-adr/copilot-0003-vuefire-auth-init.md
./copilot-documentation/copilot-appendices/README.md
./copilot-documentation/copilot-appendices/profiles-model-summary.md
./copilot-documentation/copilot-appendices/theming-fireux-apps.md
./copilot-documentation/copilot-instructions/README.md
./copilot-documentation/copilot-instructions/backfill-app-memberships.md
./copilot-documentation/copilot-instructions/documentation-style.md
./copilot-documentation/gap.md
./copilot-documentation/imported/packages/extensions/fireux-jobs/ROADMAP.md
./copilot-documentation/imported/root/config-report.md
./copilot-documentation/imported/root/create-and-register.md
./copilot-documentation/imported/root/deployment-config.md
./copilot-documentation/imported/root/ecosystem-change.md
./copilot-documentation/imported/root/profiles-stack.md
./copilot-documentation/imported/root/proposed-editable.dashboard-pages.md
./copilot-documentation/imported/root/server.md
./copilot-documentation/imported/root/stack-proposal.md
./copilot-documentation/imported/root/user-tree.md
./copilot-documentation/liturature.md
./copilot-documentation/model-interface.md
./copilot-documentation/package-docs-index.md
./copilot-documentation/roadmap.md
./docs/00-overview/repo-structure.md
./docs/10-core/figma.md
./docs/10-core/images.md
./docs/30-ecosystems/_index.md
./docs/_manifest.md
./docs/howto/work-on-app.md
./documentation-markdown-collection.md
./documentation.md
./packages/core/fireux-core/dist/runtime/composables/fireux/firestore/core/user/STABLE_README.md
./packages/core/fireux-core/docs/figma.md
./packages/core/fireux-core/docs/gap.md
./packages/core/fireux-core/docs/images-sync.md
./packages/core/fireux-core/docs/images.md
./packages/core/fireux-core/docs/liturature.md
./packages/core/fireux-core/docs/mission.md
./packages/core/fireux-core/docs/molecules-forms.md
./packages/core/fireux-core/docs/roadmap.md
./packages/core/fireux-core/src/config/README.md
./packages/core/fireux-core/src/runtime/composables/fireux/firestore/core/user/STABLE_README.md
./packages/ecosystem/fireux-cleanbox/docs/gap.md
./packages/ecosystem/fireux-cleanbox/docs/liturature.md
./packages/ecosystem/fireux-cleanbox/docs/mission.md
./packages/ecosystem/fireux-cleanbox/docs/roadmap.md
./packages/ecosystem/fireux-fireux/README.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/scratch/alignment.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/scratch/blog.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/scratch/config.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/scratch/img.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/scratch/stacks-components.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/scratch/stacks-composables.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/scratch/stacks.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/README.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/app-config.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/app-factory-report.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/app-report.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/app-utils.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/bloat-reduction-program.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/blog-report.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/chef-composables.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/composables/state-and-utils-report.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/composables/use.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/core-composables.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/current-pages-code.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/current-pages-components.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/current-pages-inventory.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/dashboard-dev-panels-todo.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/dev-health-roadmap.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/edit.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/ensure-report.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/firebse-operations-before.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/firestore-core-contract-2025-11.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/images-sync-temp.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/index-page.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/liturature-plan.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/navigation/legacy-nav-report.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/navigation/navigation-report.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/objects/legacy-firestore-objects-report.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/objects/product-composables-current.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/objects/product-composables-legacy.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/pill-report.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/scripts-audit.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/stack-scripts.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/stacks/app-v-user-comparison.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/stacks/use-app-stack.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/stacks/use-user-stack.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/tenants/landing.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/tenants/tenant-landing-follow-up.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/tree-report.md
./packages/ecosystem/fireux-fireux/docs/90-appendices/archive/temporary-reports/update-function.md
./packages/ecosystem/fireux-fireux/docs/gap.md
./packages/ecosystem/fireux-fireux/docs/liturature.md
./packages/ecosystem/fireux-fireux/docs/mission.md
./packages/ecosystem/fireux-fireux/docs/roadmap.md
./packages/ecosystem/fireux-misebox/docs/gap.md
./packages/ecosystem/fireux-misebox/docs/liturature.md
./packages/ecosystem/fireux-misebox/docs/mission.md
./packages/ecosystem/fireux-misebox/docs/roadmap.md
./packages/ecosystem/fireux-test/README.md
./packages/ecosystem/fireux-test/docs/gap.md
./packages/ecosystem/fireux-test/docs/liturature.md
./packages/ecosystem/fireux-test/docs/mission.md
./packages/ecosystem/fireux-test/docs/roadmap.md
./packages/extensions/fireux-blogs/README.md
./packages/extensions/fireux-drop/README.md
./packages/extensions/fireux-ecosystem-controller/README.md
./packages/extensions/fireux-jobs/docs/gap.md
./packages/extensions/fireux-jobs/docs/liturature.md
./packages/extensions/fireux-jobs/docs/roadmap.md
./packages/extensions/fireux-places/docs/gap.md
./packages/extensions/fireux-places/docs/liturature.md
./packages/extensions/fireux-places/docs/places-overview.md
./packages/extensions/fireux-places/docs/roadmap.md
./packages/extensions/fireux-products/README.md
./projects/cleanbox/cleanbox-app/docs/gap.md
./projects/cleanbox/cleanbox-app/docs/liturature.md
./projects/cleanbox/cleanbox-app/docs/mission.md
./projects/cleanbox/cleanbox-app/docs/roadmap.md
./projects/cleanbox/richies-reinigung/docs/gap.md
./projects/cleanbox/richies-reinigung/docs/liturature.md
./projects/cleanbox/richies-reinigung/docs/mission.md
./projects/cleanbox/richies-reinigung/docs/roadmap.md
./projects/fireux/fireux-app/docs/gap.md
./projects/fireux/fireux-app/docs/liturature.md
./projects/fireux/fireux-app/docs/mission.md
./projects/fireux/fireux-app/docs/roadmap.md
./projects/fireux/tennant/docs/gap.md
./projects/fireux/tennant/docs/liturature.md
./projects/fireux/tennant/docs/mission.md
./projects/fireux/tennant/docs/roadmap.md
./projects/misebox/misebox-app/docs/gap.md
./projects/misebox/misebox-app/docs/liturature.md
./projects/misebox/misebox-app/docs/mission.md
./projects/misebox/misebox-app/docs/roadmap.md
./projects/misebox/niederhorn/docs/gap.md
./projects/misebox/niederhorn/docs/liturature.md
./projects/misebox/niederhorn/docs/mission.md
./projects/misebox/niederhorn/docs/roadmap.md