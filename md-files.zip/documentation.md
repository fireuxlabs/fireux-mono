# FireUX Documentation

Canonical docs live at `packages/ecosystem/fireux-fireux/docs/`.

- Human-facing docs: `packages/ecosystem/fireux-fireux/docs/`
- Archived notes and temporary reports: `packages/ecosystem/fireux-fireux/docs/90-appendices/archive/`
- Agent/internal handbook: `copilot-documentation/`
- AI control prompts: `.github/prompts/`

If you are looking at a Markdown file outside these locations, consider moving it into the canonical docs or archive.
